// generated from rosidl_typesupport_introspection_c/resource/idl__type_support.c.em
// with input from system_interfaces:srv/BBeam.idl
// generated code does not contain a copyright notice

#include <stddef.h>
#include "system_interfaces/srv/detail/b_beam__rosidl_typesupport_introspection_c.h"
#include "system_interfaces/msg/rosidl_typesupport_introspection_c__visibility_control.h"
#include "rosidl_typesupport_introspection_c/field_types.h"
#include "rosidl_typesupport_introspection_c/identifier.h"
#include "rosidl_typesupport_introspection_c/message_introspection.h"
#include "system_interfaces/srv/detail/b_beam__functions.h"
#include "system_interfaces/srv/detail/b_beam__struct.h"


#ifdef __cplusplus
extern "C"
{
#endif

void system_interfaces__srv__BBeam_Request__rosidl_typesupport_introspection_c__BBeam_Request_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  system_interfaces__srv__BBeam_Request__init(message_memory);
}

void system_interfaces__srv__BBeam_Request__rosidl_typesupport_introspection_c__BBeam_Request_fini_function(void * message_memory)
{
  system_interfaces__srv__BBeam_Request__fini(message_memory);
}

static rosidl_typesupport_introspection_c__MessageMember system_interfaces__srv__BBeam_Request__rosidl_typesupport_introspection_c__BBeam_Request_message_member_array[1] = {
  {
    "structure_needs_at_least_one_member",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(system_interfaces__srv__BBeam_Request, structure_needs_at_least_one_member),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers system_interfaces__srv__BBeam_Request__rosidl_typesupport_introspection_c__BBeam_Request_message_members = {
  "system_interfaces__srv",  // message namespace
  "BBeam_Request",  // message name
  1,  // number of fields
  sizeof(system_interfaces__srv__BBeam_Request),
  false,  // has_any_key_member_
  system_interfaces__srv__BBeam_Request__rosidl_typesupport_introspection_c__BBeam_Request_message_member_array,  // message members
  system_interfaces__srv__BBeam_Request__rosidl_typesupport_introspection_c__BBeam_Request_init_function,  // function to initialize message memory (memory has to be allocated)
  system_interfaces__srv__BBeam_Request__rosidl_typesupport_introspection_c__BBeam_Request_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t system_interfaces__srv__BBeam_Request__rosidl_typesupport_introspection_c__BBeam_Request_message_type_support_handle = {
  0,
  &system_interfaces__srv__BBeam_Request__rosidl_typesupport_introspection_c__BBeam_Request_message_members,
  get_message_typesupport_handle_function,
  &system_interfaces__srv__BBeam_Request__get_type_hash,
  &system_interfaces__srv__BBeam_Request__get_type_description,
  &system_interfaces__srv__BBeam_Request__get_type_description_sources,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_system_interfaces
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, system_interfaces, srv, BBeam_Request)() {
  if (!system_interfaces__srv__BBeam_Request__rosidl_typesupport_introspection_c__BBeam_Request_message_type_support_handle.typesupport_identifier) {
    system_interfaces__srv__BBeam_Request__rosidl_typesupport_introspection_c__BBeam_Request_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &system_interfaces__srv__BBeam_Request__rosidl_typesupport_introspection_c__BBeam_Request_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif

// already included above
// #include <stddef.h>
// already included above
// #include "system_interfaces/srv/detail/b_beam__rosidl_typesupport_introspection_c.h"
// already included above
// #include "system_interfaces/msg/rosidl_typesupport_introspection_c__visibility_control.h"
// already included above
// #include "rosidl_typesupport_introspection_c/field_types.h"
// already included above
// #include "rosidl_typesupport_introspection_c/identifier.h"
// already included above
// #include "rosidl_typesupport_introspection_c/message_introspection.h"
// already included above
// #include "system_interfaces/srv/detail/b_beam__functions.h"
// already included above
// #include "system_interfaces/srv/detail/b_beam__struct.h"


#ifdef __cplusplus
extern "C"
{
#endif

void system_interfaces__srv__BBeam_Response__rosidl_typesupport_introspection_c__BBeam_Response_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  system_interfaces__srv__BBeam_Response__init(message_memory);
}

void system_interfaces__srv__BBeam_Response__rosidl_typesupport_introspection_c__BBeam_Response_fini_function(void * message_memory)
{
  system_interfaces__srv__BBeam_Response__fini(message_memory);
}

static rosidl_typesupport_introspection_c__MessageMember system_interfaces__srv__BBeam_Response__rosidl_typesupport_introspection_c__BBeam_Response_message_member_array[3] = {
  {
    "good_putts",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_INT64,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(system_interfaces__srv__BBeam_Response, good_putts),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "short_putts",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_INT64,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(system_interfaces__srv__BBeam_Response, short_putts),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "long_putts",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_INT64,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(system_interfaces__srv__BBeam_Response, long_putts),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers system_interfaces__srv__BBeam_Response__rosidl_typesupport_introspection_c__BBeam_Response_message_members = {
  "system_interfaces__srv",  // message namespace
  "BBeam_Response",  // message name
  3,  // number of fields
  sizeof(system_interfaces__srv__BBeam_Response),
  false,  // has_any_key_member_
  system_interfaces__srv__BBeam_Response__rosidl_typesupport_introspection_c__BBeam_Response_message_member_array,  // message members
  system_interfaces__srv__BBeam_Response__rosidl_typesupport_introspection_c__BBeam_Response_init_function,  // function to initialize message memory (memory has to be allocated)
  system_interfaces__srv__BBeam_Response__rosidl_typesupport_introspection_c__BBeam_Response_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t system_interfaces__srv__BBeam_Response__rosidl_typesupport_introspection_c__BBeam_Response_message_type_support_handle = {
  0,
  &system_interfaces__srv__BBeam_Response__rosidl_typesupport_introspection_c__BBeam_Response_message_members,
  get_message_typesupport_handle_function,
  &system_interfaces__srv__BBeam_Response__get_type_hash,
  &system_interfaces__srv__BBeam_Response__get_type_description,
  &system_interfaces__srv__BBeam_Response__get_type_description_sources,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_system_interfaces
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, system_interfaces, srv, BBeam_Response)() {
  if (!system_interfaces__srv__BBeam_Response__rosidl_typesupport_introspection_c__BBeam_Response_message_type_support_handle.typesupport_identifier) {
    system_interfaces__srv__BBeam_Response__rosidl_typesupport_introspection_c__BBeam_Response_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &system_interfaces__srv__BBeam_Response__rosidl_typesupport_introspection_c__BBeam_Response_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif

// already included above
// #include <stddef.h>
// already included above
// #include "system_interfaces/srv/detail/b_beam__rosidl_typesupport_introspection_c.h"
// already included above
// #include "system_interfaces/msg/rosidl_typesupport_introspection_c__visibility_control.h"
// already included above
// #include "rosidl_typesupport_introspection_c/field_types.h"
// already included above
// #include "rosidl_typesupport_introspection_c/identifier.h"
// already included above
// #include "rosidl_typesupport_introspection_c/message_introspection.h"
// already included above
// #include "system_interfaces/srv/detail/b_beam__functions.h"
// already included above
// #include "system_interfaces/srv/detail/b_beam__struct.h"


// Include directives for member types
// Member `info`
#include "service_msgs/msg/service_event_info.h"
// Member `info`
#include "service_msgs/msg/detail/service_event_info__rosidl_typesupport_introspection_c.h"
// Member `request`
// Member `response`
#include "system_interfaces/srv/b_beam.h"
// Member `request`
// Member `response`
// already included above
// #include "system_interfaces/srv/detail/b_beam__rosidl_typesupport_introspection_c.h"

#ifdef __cplusplus
extern "C"
{
#endif

void system_interfaces__srv__BBeam_Event__rosidl_typesupport_introspection_c__BBeam_Event_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  system_interfaces__srv__BBeam_Event__init(message_memory);
}

void system_interfaces__srv__BBeam_Event__rosidl_typesupport_introspection_c__BBeam_Event_fini_function(void * message_memory)
{
  system_interfaces__srv__BBeam_Event__fini(message_memory);
}

size_t system_interfaces__srv__BBeam_Event__rosidl_typesupport_introspection_c__size_function__BBeam_Event__request(
  const void * untyped_member)
{
  const system_interfaces__srv__BBeam_Request__Sequence * member =
    (const system_interfaces__srv__BBeam_Request__Sequence *)(untyped_member);
  return member->size;
}

const void * system_interfaces__srv__BBeam_Event__rosidl_typesupport_introspection_c__get_const_function__BBeam_Event__request(
  const void * untyped_member, size_t index)
{
  const system_interfaces__srv__BBeam_Request__Sequence * member =
    (const system_interfaces__srv__BBeam_Request__Sequence *)(untyped_member);
  return &member->data[index];
}

void * system_interfaces__srv__BBeam_Event__rosidl_typesupport_introspection_c__get_function__BBeam_Event__request(
  void * untyped_member, size_t index)
{
  system_interfaces__srv__BBeam_Request__Sequence * member =
    (system_interfaces__srv__BBeam_Request__Sequence *)(untyped_member);
  return &member->data[index];
}

void system_interfaces__srv__BBeam_Event__rosidl_typesupport_introspection_c__fetch_function__BBeam_Event__request(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const system_interfaces__srv__BBeam_Request * item =
    ((const system_interfaces__srv__BBeam_Request *)
    system_interfaces__srv__BBeam_Event__rosidl_typesupport_introspection_c__get_const_function__BBeam_Event__request(untyped_member, index));
  system_interfaces__srv__BBeam_Request * value =
    (system_interfaces__srv__BBeam_Request *)(untyped_value);
  *value = *item;
}

void system_interfaces__srv__BBeam_Event__rosidl_typesupport_introspection_c__assign_function__BBeam_Event__request(
  void * untyped_member, size_t index, const void * untyped_value)
{
  system_interfaces__srv__BBeam_Request * item =
    ((system_interfaces__srv__BBeam_Request *)
    system_interfaces__srv__BBeam_Event__rosidl_typesupport_introspection_c__get_function__BBeam_Event__request(untyped_member, index));
  const system_interfaces__srv__BBeam_Request * value =
    (const system_interfaces__srv__BBeam_Request *)(untyped_value);
  *item = *value;
}

bool system_interfaces__srv__BBeam_Event__rosidl_typesupport_introspection_c__resize_function__BBeam_Event__request(
  void * untyped_member, size_t size)
{
  system_interfaces__srv__BBeam_Request__Sequence * member =
    (system_interfaces__srv__BBeam_Request__Sequence *)(untyped_member);
  system_interfaces__srv__BBeam_Request__Sequence__fini(member);
  return system_interfaces__srv__BBeam_Request__Sequence__init(member, size);
}

size_t system_interfaces__srv__BBeam_Event__rosidl_typesupport_introspection_c__size_function__BBeam_Event__response(
  const void * untyped_member)
{
  const system_interfaces__srv__BBeam_Response__Sequence * member =
    (const system_interfaces__srv__BBeam_Response__Sequence *)(untyped_member);
  return member->size;
}

const void * system_interfaces__srv__BBeam_Event__rosidl_typesupport_introspection_c__get_const_function__BBeam_Event__response(
  const void * untyped_member, size_t index)
{
  const system_interfaces__srv__BBeam_Response__Sequence * member =
    (const system_interfaces__srv__BBeam_Response__Sequence *)(untyped_member);
  return &member->data[index];
}

void * system_interfaces__srv__BBeam_Event__rosidl_typesupport_introspection_c__get_function__BBeam_Event__response(
  void * untyped_member, size_t index)
{
  system_interfaces__srv__BBeam_Response__Sequence * member =
    (system_interfaces__srv__BBeam_Response__Sequence *)(untyped_member);
  return &member->data[index];
}

void system_interfaces__srv__BBeam_Event__rosidl_typesupport_introspection_c__fetch_function__BBeam_Event__response(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const system_interfaces__srv__BBeam_Response * item =
    ((const system_interfaces__srv__BBeam_Response *)
    system_interfaces__srv__BBeam_Event__rosidl_typesupport_introspection_c__get_const_function__BBeam_Event__response(untyped_member, index));
  system_interfaces__srv__BBeam_Response * value =
    (system_interfaces__srv__BBeam_Response *)(untyped_value);
  *value = *item;
}

void system_interfaces__srv__BBeam_Event__rosidl_typesupport_introspection_c__assign_function__BBeam_Event__response(
  void * untyped_member, size_t index, const void * untyped_value)
{
  system_interfaces__srv__BBeam_Response * item =
    ((system_interfaces__srv__BBeam_Response *)
    system_interfaces__srv__BBeam_Event__rosidl_typesupport_introspection_c__get_function__BBeam_Event__response(untyped_member, index));
  const system_interfaces__srv__BBeam_Response * value =
    (const system_interfaces__srv__BBeam_Response *)(untyped_value);
  *item = *value;
}

bool system_interfaces__srv__BBeam_Event__rosidl_typesupport_introspection_c__resize_function__BBeam_Event__response(
  void * untyped_member, size_t size)
{
  system_interfaces__srv__BBeam_Response__Sequence * member =
    (system_interfaces__srv__BBeam_Response__Sequence *)(untyped_member);
  system_interfaces__srv__BBeam_Response__Sequence__fini(member);
  return system_interfaces__srv__BBeam_Response__Sequence__init(member, size);
}

static rosidl_typesupport_introspection_c__MessageMember system_interfaces__srv__BBeam_Event__rosidl_typesupport_introspection_c__BBeam_Event_message_member_array[3] = {
  {
    "info",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(system_interfaces__srv__BBeam_Event, info),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "request",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is key
    true,  // is array
    1,  // array size
    true,  // is upper bound
    offsetof(system_interfaces__srv__BBeam_Event, request),  // bytes offset in struct
    NULL,  // default value
    system_interfaces__srv__BBeam_Event__rosidl_typesupport_introspection_c__size_function__BBeam_Event__request,  // size() function pointer
    system_interfaces__srv__BBeam_Event__rosidl_typesupport_introspection_c__get_const_function__BBeam_Event__request,  // get_const(index) function pointer
    system_interfaces__srv__BBeam_Event__rosidl_typesupport_introspection_c__get_function__BBeam_Event__request,  // get(index) function pointer
    system_interfaces__srv__BBeam_Event__rosidl_typesupport_introspection_c__fetch_function__BBeam_Event__request,  // fetch(index, &value) function pointer
    system_interfaces__srv__BBeam_Event__rosidl_typesupport_introspection_c__assign_function__BBeam_Event__request,  // assign(index, value) function pointer
    system_interfaces__srv__BBeam_Event__rosidl_typesupport_introspection_c__resize_function__BBeam_Event__request  // resize(index) function pointer
  },
  {
    "response",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is key
    true,  // is array
    1,  // array size
    true,  // is upper bound
    offsetof(system_interfaces__srv__BBeam_Event, response),  // bytes offset in struct
    NULL,  // default value
    system_interfaces__srv__BBeam_Event__rosidl_typesupport_introspection_c__size_function__BBeam_Event__response,  // size() function pointer
    system_interfaces__srv__BBeam_Event__rosidl_typesupport_introspection_c__get_const_function__BBeam_Event__response,  // get_const(index) function pointer
    system_interfaces__srv__BBeam_Event__rosidl_typesupport_introspection_c__get_function__BBeam_Event__response,  // get(index) function pointer
    system_interfaces__srv__BBeam_Event__rosidl_typesupport_introspection_c__fetch_function__BBeam_Event__response,  // fetch(index, &value) function pointer
    system_interfaces__srv__BBeam_Event__rosidl_typesupport_introspection_c__assign_function__BBeam_Event__response,  // assign(index, value) function pointer
    system_interfaces__srv__BBeam_Event__rosidl_typesupport_introspection_c__resize_function__BBeam_Event__response  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers system_interfaces__srv__BBeam_Event__rosidl_typesupport_introspection_c__BBeam_Event_message_members = {
  "system_interfaces__srv",  // message namespace
  "BBeam_Event",  // message name
  3,  // number of fields
  sizeof(system_interfaces__srv__BBeam_Event),
  false,  // has_any_key_member_
  system_interfaces__srv__BBeam_Event__rosidl_typesupport_introspection_c__BBeam_Event_message_member_array,  // message members
  system_interfaces__srv__BBeam_Event__rosidl_typesupport_introspection_c__BBeam_Event_init_function,  // function to initialize message memory (memory has to be allocated)
  system_interfaces__srv__BBeam_Event__rosidl_typesupport_introspection_c__BBeam_Event_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t system_interfaces__srv__BBeam_Event__rosidl_typesupport_introspection_c__BBeam_Event_message_type_support_handle = {
  0,
  &system_interfaces__srv__BBeam_Event__rosidl_typesupport_introspection_c__BBeam_Event_message_members,
  get_message_typesupport_handle_function,
  &system_interfaces__srv__BBeam_Event__get_type_hash,
  &system_interfaces__srv__BBeam_Event__get_type_description,
  &system_interfaces__srv__BBeam_Event__get_type_description_sources,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_system_interfaces
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, system_interfaces, srv, BBeam_Event)() {
  system_interfaces__srv__BBeam_Event__rosidl_typesupport_introspection_c__BBeam_Event_message_member_array[0].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, service_msgs, msg, ServiceEventInfo)();
  system_interfaces__srv__BBeam_Event__rosidl_typesupport_introspection_c__BBeam_Event_message_member_array[1].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, system_interfaces, srv, BBeam_Request)();
  system_interfaces__srv__BBeam_Event__rosidl_typesupport_introspection_c__BBeam_Event_message_member_array[2].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, system_interfaces, srv, BBeam_Response)();
  if (!system_interfaces__srv__BBeam_Event__rosidl_typesupport_introspection_c__BBeam_Event_message_type_support_handle.typesupport_identifier) {
    system_interfaces__srv__BBeam_Event__rosidl_typesupport_introspection_c__BBeam_Event_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &system_interfaces__srv__BBeam_Event__rosidl_typesupport_introspection_c__BBeam_Event_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif

#include "rosidl_runtime_c/service_type_support_struct.h"
// already included above
// #include "system_interfaces/msg/rosidl_typesupport_introspection_c__visibility_control.h"
// already included above
// #include "system_interfaces/srv/detail/b_beam__rosidl_typesupport_introspection_c.h"
// already included above
// #include "rosidl_typesupport_introspection_c/identifier.h"
#include "rosidl_typesupport_introspection_c/service_introspection.h"

// this is intentionally not const to allow initialization later to prevent an initialization race
static rosidl_typesupport_introspection_c__ServiceMembers system_interfaces__srv__detail__b_beam__rosidl_typesupport_introspection_c__BBeam_service_members = {
  "system_interfaces__srv",  // service namespace
  "BBeam",  // service name
  // the following fields are initialized below on first access
  NULL,  // request message
  // system_interfaces__srv__detail__b_beam__rosidl_typesupport_introspection_c__BBeam_Request_message_type_support_handle,
  NULL,  // response message
  // system_interfaces__srv__detail__b_beam__rosidl_typesupport_introspection_c__BBeam_Response_message_type_support_handle
  NULL  // event_message
  // system_interfaces__srv__detail__b_beam__rosidl_typesupport_introspection_c__BBeam_Response_message_type_support_handle
};


static rosidl_service_type_support_t system_interfaces__srv__detail__b_beam__rosidl_typesupport_introspection_c__BBeam_service_type_support_handle = {
  0,
  &system_interfaces__srv__detail__b_beam__rosidl_typesupport_introspection_c__BBeam_service_members,
  get_service_typesupport_handle_function,
  &system_interfaces__srv__BBeam_Request__rosidl_typesupport_introspection_c__BBeam_Request_message_type_support_handle,
  &system_interfaces__srv__BBeam_Response__rosidl_typesupport_introspection_c__BBeam_Response_message_type_support_handle,
  &system_interfaces__srv__BBeam_Event__rosidl_typesupport_introspection_c__BBeam_Event_message_type_support_handle,
  ROSIDL_TYPESUPPORT_INTERFACE__SERVICE_CREATE_EVENT_MESSAGE_SYMBOL_NAME(
    rosidl_typesupport_c,
    system_interfaces,
    srv,
    BBeam
  ),
  ROSIDL_TYPESUPPORT_INTERFACE__SERVICE_DESTROY_EVENT_MESSAGE_SYMBOL_NAME(
    rosidl_typesupport_c,
    system_interfaces,
    srv,
    BBeam
  ),
  &system_interfaces__srv__BBeam__get_type_hash,
  &system_interfaces__srv__BBeam__get_type_description,
  &system_interfaces__srv__BBeam__get_type_description_sources,
};

// Forward declaration of message type support functions for service members
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, system_interfaces, srv, BBeam_Request)(void);

const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, system_interfaces, srv, BBeam_Response)(void);

const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, system_interfaces, srv, BBeam_Event)(void);

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_system_interfaces
const rosidl_service_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__SERVICE_SYMBOL_NAME(rosidl_typesupport_introspection_c, system_interfaces, srv, BBeam)(void) {
  if (!system_interfaces__srv__detail__b_beam__rosidl_typesupport_introspection_c__BBeam_service_type_support_handle.typesupport_identifier) {
    system_interfaces__srv__detail__b_beam__rosidl_typesupport_introspection_c__BBeam_service_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  rosidl_typesupport_introspection_c__ServiceMembers * service_members =
    (rosidl_typesupport_introspection_c__ServiceMembers *)system_interfaces__srv__detail__b_beam__rosidl_typesupport_introspection_c__BBeam_service_type_support_handle.data;

  if (!service_members->request_members_) {
    service_members->request_members_ =
      (const rosidl_typesupport_introspection_c__MessageMembers *)
      ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, system_interfaces, srv, BBeam_Request)()->data;
  }
  if (!service_members->response_members_) {
    service_members->response_members_ =
      (const rosidl_typesupport_introspection_c__MessageMembers *)
      ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, system_interfaces, srv, BBeam_Response)()->data;
  }
  if (!service_members->event_members_) {
    service_members->event_members_ =
      (const rosidl_typesupport_introspection_c__MessageMembers *)
      ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, system_interfaces, srv, BBeam_Event)()->data;
  }

  return &system_interfaces__srv__detail__b_beam__rosidl_typesupport_introspection_c__BBeam_service_type_support_handle;
}

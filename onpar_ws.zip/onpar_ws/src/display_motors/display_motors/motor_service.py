import rclpy
from rclpy.node import Node

from system_interfaces.srv import MoveDistance

import time
import RPi.GPIO as GPIO

import math

DIAMETER = 3 # in inches

# defining pins
DIR1 = 24
STEP1 = 23
DIR3 = 16
STEP3 = 12

HIGH = 1
LOW = 0
 
# gpio setup

GPIO.setmode(GPIO.BCM)
GPIO.setup(DIR1,GPIO.OUT)
GPIO.setup(STEP1,GPIO.OUT)
GPIO.setup(DIR3,GPIO.OUT)
GPIO.setup(STEP3,GPIO.OUT) 

# HIGH IS CLOCKWISE
# LOW IS COUNTER CLOCKWISE
 
class Motors(Node):

	def __init__(self):
		super().__init__('motors')
		self.srv = self.create_service(MoveDistance, 'move_distance', self.moveMotors)
		self.get_logger().info('Motors are online!')

	def moveMotors(self, request, response):
		self.get_logger().info('Running the motors to move %d feet!' % (int(request.distance)))
		
		if (request.distance > 0): # if the robot needs to move forwards

			# calculate the number of rotations to move the set distance
			
			rotations = request.distance / (math.pi*DIAMETER/12)
			self.get_logger().info('%d rotations required' % rotations)
			
			steps = 200 * rotations # 200 steps in a full revolution

			steps = int(steps)

			# move the distance
			GPIO.output(DIR1, HIGH) # drive forward
			GPIO.output(DIR3, LOW)
			for i in range(0, steps): # step the number of times needed
				GPIO.output(STEP1, HIGH)
				GPIO.output(STEP3, HIGH)
				time.sleep(0.1)
				GPIO.output(STEP1, LOW)
				GPIO.output(STEP3, LOW)
				time.sleep(0.1)
		
		else: # move the robot backwards

			# calculate the number of rotations to move the set distance
			
			rotations = -request.distance / (math.pi*DIAMETER/12)
			self.get_logger().info('%d rotations required' % rotations)
			
			steps = 200 * rotations # 200 steps in a full revolution
			steps = int(steps)

			# move the distance
			GPIO.output(DIR1, LOW) # drive backward
			GPIO.output(DIR3, HIGH)
			for i in range(0, steps): # step the number of times needed
				GPIO.output(STEP1, HIGH)
				GPIO.output(STEP3, HIGH)
				time.sleep(0.1)
				GPIO.output(STEP1, LOW)
				GPIO.output(STEP3, LOW)
				time.sleep(0.1)
		
		if (request.comeback != 0):
			time.sleep(3) # wait some amount of time
			self.get_logger().info('Running the motors backwards %d feet!' % (int(request.distance)))
			# move backwards the same distance

			# calculate the number of rotations to move the set distance
			
			rotations = -request.distance / (math.pi*DIAMETER/12)
			self.get_logger().info('%d rotations required' % rotations)
			
			steps = 200 * rotations # 200 steps in a full revolution
			steps = int(steps)

			# move the distance
			GPIO.output(DIR1, LOW) # drive backward
			GPIO.output(DIR3, HIGH)
			for i in range(0, steps): # step the number of times needed
				GPIO.output(STEP1, HIGH)
				GPIO.output(STEP3, HIGH)
				time.sleep(0.1)
				GPIO.output(STEP1, LOW)
				GPIO.output(STEP3, LOW)
				time.sleep(0.1)
			
		return response

def main():
	rclpy.init()
	motors = Motors()
	rclpy.spin(motors)
	rclpy.shutdown()
	GPIO.cleanup()

if __name__ == '__main__':
	main()

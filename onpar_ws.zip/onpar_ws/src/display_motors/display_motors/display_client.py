# ros libraries
import sys
import rclpy
from rclpy.node import Node

from rclpy.executors import MultiThreadedExecutor
from rclpy.callback_groups import MutuallyExclusiveCallbackGroup, ReentrantCallbackGroup

from system_interfaces.srv import MoveDistance

from system_interfaces.srv import BBeam
from system_interfaces.msg import Display

# import necessary packages
from tkinter import *
from tkinter import ttk
from tkinter.font import Font
import tkinter as tk
from PIL import ImageTk, Image
import time
import sv_ttk

from subprocess import call

# VARIABLES

numLong = 0
numShort = 0
numGood = 0
totalPutts = 0
numPutts = 0
numBalls = 0

distMenu = None
ballSlider = None
puttSlider = None
goodLabel = None
shortLabel = None
longLabel = None
collectedLabel = None
accuracyLabel = None
statsTitle = None
setup = None
runtime = None
puttDist = None
root = None
endSession = None
startNewSession = None

keepUpdating = 0

class DisplayAsync(Node):

	def __init__(self):
				
		global distMenu, ballSlider, puttSlider, goodLabel, shortLabel, longLabel, collectedLabel, accuracyLabel, setup, runtime, puttDist, root, statsTitle, endSession, startNewSession
		
		super().__init__('display_async')

		# set up callback groups that i'm not sure matter
		motor_cb_group = MutuallyExclusiveCallbackGroup()
		publisher_timer_cb_group = MutuallyExclusiveCallbackGroup()
		client_cb_group = MutuallyExclusiveCallbackGroup()
		
		# client
		self.cli = self.create_client(MoveDistance, 'move_distance', callback_group=motor_cb_group) # client to ask for the motors to move
		self.bbeamCli = self.create_client(BBeam, 'balls_collected', callback_group=client_cb_group) # client to request updates from the break-beam

		# publisher
		self.publisher_ = self.create_publisher(Display, 'display_data', 10, callback_group=publisher_timer_cb_group) # publisher that says how many golf balls and number of putts in the session
		
		# START OF ROOT

		root = Tk() # define a root window
		
		root.bind('<Control-c>', quit) # set up exit keyboard interrupt

		text_font = Font(family="Helvetica", size=36) # set up font of choice
		text_font_small = Font(family="Helvetica", size=30) 
		text_font_bold = Font(family="Helvetica", size=30, weight="bold") 
		text_font_small_bold = Font(family="Helvetica", size=30, weight="bold") 

		root.attributes("-fullscreen", True) # set the window to fullscreen

		bgImage = '/home/on-par/onpar_ws/green.png' # set up a variable to store the image
		bg= PhotoImage(file= bgImage) # input the image
		bgLabel= Label(root, i=bg) # use the image for a label
		bgLabel.place(x = 0, y = 0) # place the label
		bgLabel.lower() # lower to background

		# END OF ROOT
		
		# START OF SETUP FRAME

		setup = ttk.Frame(root, padding=10) # creates a frame to hold data
		setup.grid() # creates a grid on the frame to organize labels
		setup.place(x = 0, y = 0) # place the frame

		welcomeTitle = Label(setup, text="on PAR : Putting Aid Robot\n", font=text_font_small_bold).grid(column=0, row=0)

		# set up sliders
		Label(setup, text="Number of balls:", font=text_font).grid(column=0, row=1)
		ballSlider = Scale(setup, length=200, from_=1, to=4, orient=HORIZONTAL, font=text_font)
		ballSlider.grid(column=1, row=1)

		Label(setup, text="Number of putts:", font=text_font).grid(column=0, row=2)
		puttSlider = Scale(setup, length=200, from_=1, to=10, orient=HORIZONTAL, font=text_font)
		puttSlider.grid(column=1, row=2)

		# label for putting distances
		welcome = Label(setup, text="\nPutting distance (in ft):\n", font=text_font).grid(column=0, row=3)

		# set up options for putting distances
		puttDist = StringVar(root)
		puttingDistances = [5, 10, 15, 20]
		puttDist.set(puttingDistances[0])

		distMenu = OptionMenu(setup, puttDist, *puttingDistances)
		distMenu.config(font=text_font)
		distMenu.grid(column=1, row=3)

		menu = setup.nametowidget(distMenu.menuname)  # Get menu widget.
		menu.config(font=text_font)  # Set the dropdown menu's font

		startSession = tk.Button(setup, text="Start session", command=self.start, font=text_font).grid(column=0, row=6)

		powerOff = tk.Button(setup, text="Shutdown", command=self.turnOff, font=text_font_small).grid(column=1, row=0)

		# END OF SETUP FRAME

		# START OF RUNTIME FRAME

		runtime = ttk.Frame(root, padding=50) # creates a frame to hold data
		runtime.grid() # creates a grid on the frame to organize labels
		runtime.place(x = 0, y = 0) # place the frame

		statsTitle = Label(runtime, text="Session Statistics", font=text_font_bold)
		statsTitle.grid(column=0, row=0)

		# set labels for good, short, and long putts
		goodLabel = Label(runtime, text=f"Good Putts = {numGood}", font=text_font_small)
		goodLabel.grid(column=0, row=1)
		shortLabel = Label(runtime, text=f"Short Putts = {numShort}", font=text_font_small)
		shortLabel.grid(column=0, row=2)
		longLabel = Label(runtime, text=f"Long Putts = {numLong}", font=text_font_small)
		longLabel.grid(column=0, row=3)

		collectedLabel = Label(runtime, text="Balls collected = N/A", font=text_font_small)
		collectedLabel.grid(column=0, row=5)
		accuracyLabel = Label(runtime, text="Accuracy = N/A", font=text_font_small)
		accuracyLabel.grid(column=0, row=4)

		endSession = tk.Button(runtime, text="End session", command=self.results, font=text_font)
		endSession.grid(column=0, row=6)
		startNewSession = tk.Button(runtime, text="Start a new session?", command=self.restart, font=text_font)
		startNewSession.grid(column=0, row=6)
		startNewSession.grid_forget()

		runtime.lower()
		
		# END OF RUNTIME FRAME

		sv_ttk.set_theme("dark") # fancy mode

		root.mainloop()
	
	# function that sets up the motor to move a given distance				
	def send_request(self, distance, comeback): # define the request to move a set distance
		self.motorReq.distance = distance
		self.motorReq.comeback = comeback		
		return self.cli.call_async(self.motorReq)

	# timer that reccurs every second and requests an update from the break-beams on the number of good, short, and long putts
	def update_timer(self):
		global root, keepUpdating

		global numLong, numShort, numGood, totalPutts, numPutts, numBalls

		global distMenu, ballSlider, puttSlider, goodLabel, shortLabel, longLabel, collectedLabel, accuracyLabel, setup, runtime, puttDist

		if (keepUpdating == 1): # only continue if a session is going

			self.bbeamReq = BBeam.Request() # create request from the break-beams
			future = self.bbeamCli.call_async(self.bbeamReq)

			rclpy.spin_until_future_complete(self, future) # spin until there's a result
			
			updatedData = future.result() # set the result
			
			#self.get_logger().info('I received %d good putts, %d short putts, and %d long putts!' % (updatedData.good_putts, updatedData.short_putts, updatedData.long_putts))
			
			numGood = updatedData.good_putts
			numShort = updatedData.short_putts
			numLong = updatedData.long_putts
			totalPutts = numGood + numShort + numLong
			
			# calculate the accuracy
			if (totalPutts != 0):
				accuracy = round(numGood/totalPutts * 100,2)
			else:
				accuracy = 0

			# update the display
			goodLabel.config(text=f"Good Putts = {numGood}")
			shortLabel.config(text=f"Short Putts = {numShort}")
			longLabel.config(text=f"Long Putts = {numLong}")
			collectedLabel.config(text=f"Balls collected = {totalPutts}/{numPutts}")
			accuracyLabel.config(text=f"Accuracy = {accuracy}%")
				
			if (totalPutts == numPutts and numPutts != 0):
				self.results()
			
			root.after(1000, self.update_timer)

	# publisher that tells the break-beam the number of balls and putts to expect
	def publisher_callback(self):
		
		global numBalls, numPutts
		
		msg = Display() # set up message
		# fill message
		msg.num_balls = numBalls
		msg.num_putts = numPutts
		
		# publish message
		self.publisher_.publish(msg)
		
		#self.get_logger().info('Publishing the display input!')

	# TKINTER FUNCTIONS

	def turnOff(self):
		#exit()
		call("systemctl poweroff", shell=True)

	# functions to switch between menus at the start from the setup to the runtime menu
	def start(self):
		global keepUpdating
		
		global numLong, numShort, numGood, totalPutts, numPutts, numBalls, accuracy

		global distMenu, ballSlider, puttSlider, goodLabel, shortLabel, longLabel, collectedLabel, accuracyLabel, setup, runtime, puttDist, statsTitle, startNewSession, endSession
			
		dist = int(puttDist.get())
		numBalls = ballSlider.get()
		numPutts = puttSlider.get() 

		# send the data to the break-beam to know how many balls to expect
		self.publisher_callback()
		
		# calculate accuracy	
		if (totalPutts != 0):
			accuracy = round(numGood/totalPutts * 100,2)
		else:
			accuracy = 0
		
		# reset runtime frame
		collectedLabel.grid(column=0, row=5)
		statsTitle.config(text="Session Statistics")

		startNewSession.grid_forget()
		endSession.grid(column=0, row=6)
			 
		goodLabel.config(text=f"Good Putts = {numGood}")
		shortLabel.config(text=f"Short Putts = {numShort}")
		longLabel.config(text=f"Long Putts = {numLong}")
		collectedLabel.config(text=f"Balls collected = {totalPutts}/{numPutts}")
		accuracyLabel.config(text=f"Accuracy = {accuracy}%")

		setup.lower()
		runtime.lift()

		self.motorReq = MoveDistance.Request() # create the drive motors
		self.send_request(dist, 0)

		keepUpdating = 1
		self.update_timer()

	# results screen that tells the robot to go back to the user and show the results
	def results(self):

		global keepUpdating
		# stop the update timer
		keepUpdating = 0

		global numLong, numShort, numGood, totalPutts, numPutts, numBalls, accuracy, puttDist, runtime, collectedLabel, statsTitle, endSession, startNewSession

		collectedLabel.grid_forget()
		
		endSession.grid_forget()
		startNewSession.grid(column=0, row=6)
		
		statsTitle.config(text="Final Results")
		
		# call the motor to return to the user by driving a distance of puttDist
		dist = -int(puttDist.get())
		self.motorReq = MoveDistance.Request() # create the drive motors
		self.send_request(dist, 0)

	# function that resets everything at the end of a session once the user hits the restart button
	def restart(self):
			
		global numLong, numShort, numGood, totalPutts, numPutts, numBalls
	   
		global distMenu, ballSlider, puttSlider, goodLabel, shortLabel, longLabel, collectedLabel, accuracyLabel, setup, runtime, puttDist

		setup.lift()
		runtime.lower()
		numLong = 0
		numShort = 0
		numGood = 0
		totalPutts = 0
		numPutts = 0
		numBalls = 0
		
def main():
	rclpy.init()

	display = DisplayAsync()
	executor = MultiThreadedExecutor()
	executor.add_node(display)
	
	executor.spin()

	display.destroy_node()
	rclpy.shutdown()


if __name__ == '__main__':
	main()

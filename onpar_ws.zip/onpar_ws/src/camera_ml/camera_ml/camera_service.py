from system_interfaces.srv import CameraData # camera variables

import rclpy
from rclpy.node import Node

	
class Camera(Node):

	def __init__(self):
		super().__init__('flywheels')
		self.srv = self.create_service(CameraData, 'ball_data', self.checkCamera)
		self.get_logger().info('Camera is online!')

	def checkCamera(self, request, response):
		ballData = [0,0,-24,-24,10,-20] # detected balls, pass the result as a list
		response.ball_data = ballData
		return response
		
def main():
	rclpy.init()
	camera = Camera()
	rclpy.spin(camera)
	rclpy.shutdown()

if __name__ == '__main__':
	main()


# import libraries
import RPi.GPIO as GPIO

import rclpy
from rclpy.node import Node

from system_interfaces.srv import MoveFlywheels

import time

# defining pins
SERVO = 19

DIR2 = 21
STEP2 = 20

HIGH = 1
LOW = 0

IN1 = 14
IN2 = 15
IN3 = 5
IN4 = 6
EN1 = 13
EN2 = 18

MIN_DUTY = 1.5
MAX_DUTY = 22

# gpio setup
GPIO.setmode(GPIO.BCM)

# servo setup
GPIO.setup(SERVO,GPIO.OUT)
servo = GPIO.PWM(SERVO, 50)
servo.start(0)

# turnstile setup
GPIO.setup(DIR2,GPIO.OUT)
GPIO.setup(STEP2,GPIO.OUT)

GPIO.output(DIR2, HIGH)

# flywheels setup
GPIO.setup(IN1,GPIO.OUT)
GPIO.setup(IN2,GPIO.OUT)
GPIO.setup(IN3,GPIO.OUT)
GPIO.setup(IN4,GPIO.OUT)
GPIO.setup(EN1,GPIO.OUT)
GPIO.setup(EN2,GPIO.OUT)
enable1 = GPIO.PWM(EN1,490)
enable2 = GPIO.PWM(EN2,490)

# LOW/HIGH = CCW
# HIGH/LOW = CW
# HIGH/HIGH OR LOW/LOW = OFF

# start with all flywheels off
GPIO.output(IN1, LOW)
GPIO.output(IN2, LOW)
GPIO.output(IN3, LOW)
GPIO.output(IN4, LOW)

# start flywheel pwm
enable1.start(0)
enable2.start(0)

class Flywheels(Node):

	def __init__(self):
		super().__init__('flywheels')
		self.srv = self.create_service(MoveFlywheels, 'move_flywheels', self.runFlywheels)
		self.get_logger().info('Flywheels are online!')


	def runFlywheels(self, request, response):
		
		# change the flywheels to run the appropriate speed
		enable1.ChangeDutyCycle(100)
		enable2.ChangeDutyCycle(100)
		
		if (request.direction == 0): # determines direction of the flywheels
			self.get_logger().info('Running the flywheels backwards to retrieve out the golf ball!') # run the flywheels backwards
			
			# set the flywheels to backwards
			GPIO.output(IN1, HIGH)
			GPIO.output(IN2, LOW)
			GPIO.output(IN3, LOW)
			GPIO.output(IN4, HIGH)
			
			time.sleep(5) # wait some given time
			
			# stop running the flywheels
			GPIO.output(IN1, LOW)
			GPIO.output(IN2, LOW)
			GPIO.output(IN3, LOW)
			GPIO.output(IN4, LOW)

			# TURNSTILE
			self.get_logger().info('Moving turnstile for the next golf ball!')# move the turnstile 
			for i in range(0, 50): # 200 steps for a full revolution, 50 steps for 90 degrees
				GPIO.output(STEP2, HIGH)
				time.sleep(0.1)
				GPIO.output(STEP2, LOW)
				time.sleep(0.1)

			return response
		else:
			self.get_logger().info('Running the flywheels forward to launch out the golf ball!') # run the flywheels forward

			# set flywheels to forward
			GPIO.output(IN1, LOW)
			GPIO.output(IN2, HIGH)
			GPIO.output(IN3, HIGH)
			GPIO.output(IN4, LOW)

			for i in range(1,4): # run 4 times, or for the number of golf balls (eventually)
				
				# SERVO
				self.get_logger().info('Running the servo to kick the golf ball!')# kick out the golf ball
				servo.ChangeDutyCycle(int((90 - 0) * (MAX_DUTY - MIN_DUTY) / 180 + MIN_DUTY))
				time.sleep(0.4)
				servo.ChangeDutyCycle(int((0 - 0) * (MAX_DUTY - MIN_DUTY) / 180 + MIN_DUTY))
				time.sleep(3)

				# TURNSTILE
				self.get_logger().info('Moving turnstile for the next golf ball!')# move the turnstile 
				for i in range(0, 50): # 200 steps for a full revolution, 50 steps for 90 degrees
					GPIO.output(STEP2, HIGH)
					time.sleep(0.1)
					GPIO.output(STEP2, LOW)
					time.sleep(0.1)

				time.sleep(3)
				
			# turn off the flywheels
			GPIO.output(IN1, LOW)
			GPIO.output(IN2, LOW)
			GPIO.output(IN3, LOW)
			GPIO.output(IN4, LOW)
			
			return response

def main():
	rclpy.init()
	flywheels = Flywheels()
	rclpy.spin(flywheels)
	rclpy.shutdown()
	GPIO.cleanup()

if __name__ == '__main__':
	main()

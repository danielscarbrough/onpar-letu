# ros libraries
import sys
import rclpy
from rclpy.executors import MultiThreadedExecutor
from rclpy.callback_groups import MutuallyExclusiveCallbackGroup, ReentrantCallbackGroup
from rclpy.node import Node

from system_interfaces.srv import MoveFlywheels # flywheels request
from system_interfaces.srv import MoveDistance # wheel motors request

from system_interfaces.srv import BBeam
from system_interfaces.msg import Display

# gpio libraries
import RPi.GPIO as GPIO
import time

# variables
broken = 0
startTime = 0
endTime = 0
totalTime = 0

firstBeam = 10
secondBeam = 9

numOfBalls = 0

goodPutts = 0
shortPutts = 0
longPutts = 0

numPutts = 0
numBallsGiven = 0

bbeamsOn = 0

# setup
GPIO.setmode(GPIO.BCM)
GPIO.setup(firstBeam,GPIO.IN, pull_up_down=GPIO.PUD_UP)
GPIO.setup(secondBeam,GPIO.IN, pull_up_down=GPIO.PUD_UP)

class BBeamAsync(Node):

	def __init__(self):
		
		super().__init__('bbeam_async')
		
		# create callback groups that may or may not do anything
		motor_cb_group = MutuallyExclusiveCallbackGroup()
		flywheels_cb_group = MutuallyExclusiveCallbackGroup()
		bbeam_timer_cb_group = MutuallyExclusiveCallbackGroup()
		subscriber_cb_group = MutuallyExclusiveCallbackGroup()
		camera_cb_group = MutuallyExclusiveCallbackGroup()

		
		# clients
		self.motorCli = self.create_client(MoveDistance, 'move_distance',callback_group=motor_cb_group) # client to start flywheels
		self.flywheelsCli = self.create_client(MoveFlywheels, 'move_flywheels',callback_group=flywheels_cb_group) # client to move the wheel motors
		self.cameraCli = self.create_client(CameraData, 'ball_data', callback_group=camera_cb_group) # client to request updates from the break-beam
				
		# listeners		
		self.subscription = self.create_subscription(Display, 'display_data', self.listener_callback, 10, callback_group=subscriber_cb_group) # subscriber listening for display data
		self.subscription
		
		# timers
		self.timer = self.create_timer(0.5, self.bbeam_timer_callback, callback_group=bbeam_timer_cb_group) # timer to run break-beam code repeatedly

		# services
		self.srv = self.create_service(BBeam, 'balls_collected', self.reportPutts)

		self.flywheelsReq = MoveFlywheels.Request() # create the flywheels
		self.motorReq = MoveDistance.Request() # create the drive motors
		self.displayReq = BBeam.Request() # create the updater for the display

	# function that sends the display the number of good, short, and long putts
	def reportPutts(self, request, response):
		
		global goodPutts, shortPutts, longPutts
		
		response.good_putts = goodPutts
		response.short_putts = shortPutts
		response.long_putts = longPutts
	
		return response

	# function that keeps track of the number of balls in storage and sends the balls back to the user when full
	def countBalls(self):
		global numOfBalls
		numOfBalls = numOfBalls + 1	# increase the amount of balls in storage
			
		time.sleep(3) # wait for 3 seconds to let the golf ball settle
		if (numOfBalls == numBallsGiven): # if the number of balls is equal to the number of balls the user has (or 4), then call the flywheels to spit them back out
		
		# CHECK IF ANY GOLF BALLS NEED TO BE COLLECTED BEFORE SPITTING THEM OUT
			
			
			
			self.send_flywheels_request(1) # request the flywheels to spin forwards 
			numOfBalls = 0

	# requests to move the motor and flywheels
	def send_motor_request(self, distance, comeback): # define the request to move a set distance
		self.motorReq.distance = distance
		self.motorReq.comeback = comeback
		return self.motorCli.call_async(self.motorReq)

	def send_flywheels_request(self, direction): # define the request to move a set direction
		self.flywheelsReq.direction = direction
		return self.flywheelsCli.call_async(self.flywheelsReq)

	# a subscriber that keeps track of how many golf balls and putts the user has
	def listener_callback(self, msg):
		global numPutts, numBallsGiven, bbeamsOn
		
		self.get_logger().info('The golfer has %d golf balls and is putting %d for this session'% (msg.num_balls, msg.num_putts))
		numPutts = msg.num_putts
		numBallsGiven = msg.num_balls
		
		bbeamsOn = 1

	# this function repeats forever, checking for the break-beam's status and responding in kind	
	def bbeam_timer_callback(self):

		global goodPutts, shortPutts, longPutts, bbeamsOn, numOfBalls
		
		short = 0
		
		#while True: # do forever
		while not self.flywheelsCli.wait_for_service(timeout_sec=1.0): # wait for the flywheel service to come online
			self.get_logger().info('waiting for the flywheels to come online...')
			
		if (bbeamsOn == 1):
			self.get_logger().info('waiting for the first break beam to sense a golfball...')

			# FIRST BREAK BEAM
			while (GPIO.input(firstBeam)): # wait to sense a golf ball when the signal is high
				# ask the camera if a golf ball has stopped yet, if it has, break out of the while and define it as short				
				time.sleep(0.1)
				
				# GET CAMERA DATA
				self.cameraReq = CameraData.Request() # create request from the break-beams
				future = self.cameraCli.call_async(self.cameraReq)
				rclpy.spin_until_future_complete(self, future) # spin until there's a result				
				ballData = future.result() # set the result				
				ballData = ballData.ball_data				
				ballData = [i for i in zip(*[iter(ballData)]*2)] # take the list and make it into a list of tuples
			
				# check if there is a new set of stopped coordinates
				if len(ballData) > numOfBalls: # if there are more coordinates than balls recorded
					self.get_logger().info('The camera recorded the ball stopped without breaking the first break-beam, must be a short ball :(')			
					shortPutts = shortPutts + 1
					self.countBalls() # recount number of golf balls
					
					# check if the coordinates of the ball are not in front of the hole, if they are, then call the flywheels
					for balls in ballData:
						if abs(balls[0]) < 3: # if one of the x coordinates is less than 3 inches from the center
							# move the motors forward until the ball does, turn on the flywheels, and then move a little further
							self.send_motor_request(int(balls[1]) + 3, 1) # move the motors the y distance and then some
							self.send_flywheels_request(0) # request the flywheels to spin backwards 										
					
					break
			if short == 0: # if the first break beam was actually broken
				
				#self.get_logger().info('I SENSE A GOLF BALL!!')			
				startTime = time.time_ns() # start the timer
			
				while (not GPIO.input(firstBeam)): # wait until the golf ball has passed
					pass 
					
				endTime = time.time_ns() # end the timer

				totalTime = (endTime-startTime) / 1_000_000_000
				
				#self.get_logger().info('I waited for %d seconds!' % (int(totalTime)))
				ballSpeed = int(round(0.14/totalTime, 2))
				self.get_logger().info('For a golf ball of size 1.68 inches, the golf ball was traveling at %d ft/sec!' % ballSpeed)

				# send recorded speed to the display

				# SECOND BREAK BEAM
				self.get_logger().info('waiting for the second break beam to sense a golfball...')

				#secondTimeout = 0 # start timing how long since the ball passed the first break beam

				while (GPIO.input(secondBeam)): # wait to sense a golf ball, or wait for the ball to stop
					# ask the camera if a golf ball has stopped yet, if it has, break out of the while and define it as short
					time.sleep(0.1)
					
					# GET CAMERA DATA
					self.cameraReq = CameraData.Request() # create request from the break-beams
					future = self.cameraCli.call_async(self.cameraReq)
					rclpy.spin_until_future_complete(self, future) # spin until there's a result				
					ballData = future.result() # set the result				
					ballData = ballData.ball_data				
					ballData = [i for i in zip(*[iter(ballData)]*2)] # take the list and make it into a list of tuples
				
					# check if there is a new set of stopped coordinates
					if len(ballData) > numOfBalls: # if there are more coordinates than balls recorded
						self.get_logger().info('The camera recorded the ball stopped without breaking the second break-beam, must be a short ball :(')			
						
						# move the motors forward until the ball does, turn on the flywheels, and then move a little further
						self.send_motor_request(5, 1)

						self.send_flywheels_request(0) # request the flywheels to spin backwards 

						shortPutts = shortPutts + 1
						self.countBalls() # recount number of golf balls
						break
						
				if (short == 0): # if the ball reached the second breakbeam
					
					#self.get_logger().info('I SENSE A GOLF BALL!!')			
					startTime = time.time_ns() # start the timer
				
					while (not GPIO.input(secondBeam)): # wait until the golf ball has passed
						pass 
						
					endTime = time.time_ns() # end the timer

					totalTime = (endTime-startTime) / 1_000_000_000

					# request the flywheels to start spinning once the ball has passed the second break-beam-- maybe after first instead?
					#self.get_logger().info('requesting the flywheels to spin!')

					self.send_flywheels_request(0) # request the flywheels to spin backwards 
					
					if (ballSpeed > 4): # if the ball is moving faster than 4 feet per second, it would skip the hole
						longPutts = longPutts + 1
					else:
						goodPutts = goodPutts + 1

					self.countBalls() # recount number of golf balls
										
def main():
	rclpy.init()

	bbeam = BBeamAsync() # create a client	

	executor = MultiThreadedExecutor()
	executor.add_node(bbeam)
	
	executor.spin()

	bbeam.destroy_node() # stop when finished
	rclpy.shutdown()


if __name__ == '__main__':
	main()

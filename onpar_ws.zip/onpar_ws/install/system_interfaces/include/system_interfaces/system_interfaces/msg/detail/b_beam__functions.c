// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from system_interfaces:msg/BBeam.idl
// generated code does not contain a copyright notice
#include "system_interfaces/msg/detail/b_beam__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


bool
system_interfaces__msg__BBeam__init(system_interfaces__msg__BBeam * msg)
{
  if (!msg) {
    return false;
  }
  // good_putts
  // short_putts
  // long_putts
  return true;
}

void
system_interfaces__msg__BBeam__fini(system_interfaces__msg__BBeam * msg)
{
  if (!msg) {
    return;
  }
  // good_putts
  // short_putts
  // long_putts
}

bool
system_interfaces__msg__BBeam__are_equal(const system_interfaces__msg__BBeam * lhs, const system_interfaces__msg__BBeam * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // good_putts
  if (lhs->good_putts != rhs->good_putts) {
    return false;
  }
  // short_putts
  if (lhs->short_putts != rhs->short_putts) {
    return false;
  }
  // long_putts
  if (lhs->long_putts != rhs->long_putts) {
    return false;
  }
  return true;
}

bool
system_interfaces__msg__BBeam__copy(
  const system_interfaces__msg__BBeam * input,
  system_interfaces__msg__BBeam * output)
{
  if (!input || !output) {
    return false;
  }
  // good_putts
  output->good_putts = input->good_putts;
  // short_putts
  output->short_putts = input->short_putts;
  // long_putts
  output->long_putts = input->long_putts;
  return true;
}

system_interfaces__msg__BBeam *
system_interfaces__msg__BBeam__create(void)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  system_interfaces__msg__BBeam * msg = (system_interfaces__msg__BBeam *)allocator.allocate(sizeof(system_interfaces__msg__BBeam), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(system_interfaces__msg__BBeam));
  bool success = system_interfaces__msg__BBeam__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
system_interfaces__msg__BBeam__destroy(system_interfaces__msg__BBeam * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    system_interfaces__msg__BBeam__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
system_interfaces__msg__BBeam__Sequence__init(system_interfaces__msg__BBeam__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  system_interfaces__msg__BBeam * data = NULL;

  if (size) {
    data = (system_interfaces__msg__BBeam *)allocator.zero_allocate(size, sizeof(system_interfaces__msg__BBeam), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = system_interfaces__msg__BBeam__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        system_interfaces__msg__BBeam__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
system_interfaces__msg__BBeam__Sequence__fini(system_interfaces__msg__BBeam__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      system_interfaces__msg__BBeam__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

system_interfaces__msg__BBeam__Sequence *
system_interfaces__msg__BBeam__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  system_interfaces__msg__BBeam__Sequence * array = (system_interfaces__msg__BBeam__Sequence *)allocator.allocate(sizeof(system_interfaces__msg__BBeam__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = system_interfaces__msg__BBeam__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
system_interfaces__msg__BBeam__Sequence__destroy(system_interfaces__msg__BBeam__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    system_interfaces__msg__BBeam__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
system_interfaces__msg__BBeam__Sequence__are_equal(const system_interfaces__msg__BBeam__Sequence * lhs, const system_interfaces__msg__BBeam__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!system_interfaces__msg__BBeam__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
system_interfaces__msg__BBeam__Sequence__copy(
  const system_interfaces__msg__BBeam__Sequence * input,
  system_interfaces__msg__BBeam__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(system_interfaces__msg__BBeam);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    system_interfaces__msg__BBeam * data =
      (system_interfaces__msg__BBeam *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!system_interfaces__msg__BBeam__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          system_interfaces__msg__BBeam__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!system_interfaces__msg__BBeam__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}

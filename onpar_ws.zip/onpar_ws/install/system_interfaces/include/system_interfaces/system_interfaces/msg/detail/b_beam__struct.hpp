// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from system_interfaces:msg/BBeam.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "system_interfaces/msg/b_beam.hpp"


#ifndef SYSTEM_INTERFACES__MSG__DETAIL__B_BEAM__STRUCT_HPP_
#define SYSTEM_INTERFACES__MSG__DETAIL__B_BEAM__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__system_interfaces__msg__BBeam __attribute__((deprecated))
#else
# define DEPRECATED__system_interfaces__msg__BBeam __declspec(deprecated)
#endif

namespace system_interfaces
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct BBeam_
{
  using Type = BBeam_<ContainerAllocator>;

  explicit BBeam_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->good_putts = 0ll;
      this->short_putts = 0ll;
      this->long_putts = 0ll;
    }
  }

  explicit BBeam_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_alloc;
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->good_putts = 0ll;
      this->short_putts = 0ll;
      this->long_putts = 0ll;
    }
  }

  // field types and members
  using _good_putts_type =
    int64_t;
  _good_putts_type good_putts;
  using _short_putts_type =
    int64_t;
  _short_putts_type short_putts;
  using _long_putts_type =
    int64_t;
  _long_putts_type long_putts;

  // setters for named parameter idiom
  Type & set__good_putts(
    const int64_t & _arg)
  {
    this->good_putts = _arg;
    return *this;
  }
  Type & set__short_putts(
    const int64_t & _arg)
  {
    this->short_putts = _arg;
    return *this;
  }
  Type & set__long_putts(
    const int64_t & _arg)
  {
    this->long_putts = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    system_interfaces::msg::BBeam_<ContainerAllocator> *;
  using ConstRawPtr =
    const system_interfaces::msg::BBeam_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<system_interfaces::msg::BBeam_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<system_interfaces::msg::BBeam_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      system_interfaces::msg::BBeam_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<system_interfaces::msg::BBeam_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      system_interfaces::msg::BBeam_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<system_interfaces::msg::BBeam_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<system_interfaces::msg::BBeam_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<system_interfaces::msg::BBeam_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__system_interfaces__msg__BBeam
    std::shared_ptr<system_interfaces::msg::BBeam_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__system_interfaces__msg__BBeam
    std::shared_ptr<system_interfaces::msg::BBeam_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const BBeam_ & other) const
  {
    if (this->good_putts != other.good_putts) {
      return false;
    }
    if (this->short_putts != other.short_putts) {
      return false;
    }
    if (this->long_putts != other.long_putts) {
      return false;
    }
    return true;
  }
  bool operator!=(const BBeam_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct BBeam_

// alias to use template instance with default allocator
using BBeam =
  system_interfaces::msg::BBeam_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace system_interfaces

#endif  // SYSTEM_INTERFACES__MSG__DETAIL__B_BEAM__STRUCT_HPP_

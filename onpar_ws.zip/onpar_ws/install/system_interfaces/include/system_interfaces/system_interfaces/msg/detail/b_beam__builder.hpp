// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from system_interfaces:msg/BBeam.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "system_interfaces/msg/b_beam.hpp"


#ifndef SYSTEM_INTERFACES__MSG__DETAIL__B_BEAM__BUILDER_HPP_
#define SYSTEM_INTERFACES__MSG__DETAIL__B_BEAM__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "system_interfaces/msg/detail/b_beam__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace system_interfaces
{

namespace msg
{

namespace builder
{

class Init_BBeam_long_putts
{
public:
  explicit Init_BBeam_long_putts(::system_interfaces::msg::BBeam & msg)
  : msg_(msg)
  {}
  ::system_interfaces::msg::BBeam long_putts(::system_interfaces::msg::BBeam::_long_putts_type arg)
  {
    msg_.long_putts = std::move(arg);
    return std::move(msg_);
  }

private:
  ::system_interfaces::msg::BBeam msg_;
};

class Init_BBeam_short_putts
{
public:
  explicit Init_BBeam_short_putts(::system_interfaces::msg::BBeam & msg)
  : msg_(msg)
  {}
  Init_BBeam_long_putts short_putts(::system_interfaces::msg::BBeam::_short_putts_type arg)
  {
    msg_.short_putts = std::move(arg);
    return Init_BBeam_long_putts(msg_);
  }

private:
  ::system_interfaces::msg::BBeam msg_;
};

class Init_BBeam_good_putts
{
public:
  Init_BBeam_good_putts()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_BBeam_short_putts good_putts(::system_interfaces::msg::BBeam::_good_putts_type arg)
  {
    msg_.good_putts = std::move(arg);
    return Init_BBeam_short_putts(msg_);
  }

private:
  ::system_interfaces::msg::BBeam msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::system_interfaces::msg::BBeam>()
{
  return system_interfaces::msg::builder::Init_BBeam_good_putts();
}

}  // namespace system_interfaces

#endif  // SYSTEM_INTERFACES__MSG__DETAIL__B_BEAM__BUILDER_HPP_

// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from system_interfaces:msg/Display.idl
// generated code does not contain a copyright notice
#include "system_interfaces/msg/detail/display__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


bool
system_interfaces__msg__Display__init(system_interfaces__msg__Display * msg)
{
  if (!msg) {
    return false;
  }
  // num_balls
  // num_putts
  return true;
}

void
system_interfaces__msg__Display__fini(system_interfaces__msg__Display * msg)
{
  if (!msg) {
    return;
  }
  // num_balls
  // num_putts
}

bool
system_interfaces__msg__Display__are_equal(const system_interfaces__msg__Display * lhs, const system_interfaces__msg__Display * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // num_balls
  if (lhs->num_balls != rhs->num_balls) {
    return false;
  }
  // num_putts
  if (lhs->num_putts != rhs->num_putts) {
    return false;
  }
  return true;
}

bool
system_interfaces__msg__Display__copy(
  const system_interfaces__msg__Display * input,
  system_interfaces__msg__Display * output)
{
  if (!input || !output) {
    return false;
  }
  // num_balls
  output->num_balls = input->num_balls;
  // num_putts
  output->num_putts = input->num_putts;
  return true;
}

system_interfaces__msg__Display *
system_interfaces__msg__Display__create(void)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  system_interfaces__msg__Display * msg = (system_interfaces__msg__Display *)allocator.allocate(sizeof(system_interfaces__msg__Display), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(system_interfaces__msg__Display));
  bool success = system_interfaces__msg__Display__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
system_interfaces__msg__Display__destroy(system_interfaces__msg__Display * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    system_interfaces__msg__Display__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
system_interfaces__msg__Display__Sequence__init(system_interfaces__msg__Display__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  system_interfaces__msg__Display * data = NULL;

  if (size) {
    data = (system_interfaces__msg__Display *)allocator.zero_allocate(size, sizeof(system_interfaces__msg__Display), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = system_interfaces__msg__Display__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        system_interfaces__msg__Display__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
system_interfaces__msg__Display__Sequence__fini(system_interfaces__msg__Display__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      system_interfaces__msg__Display__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

system_interfaces__msg__Display__Sequence *
system_interfaces__msg__Display__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  system_interfaces__msg__Display__Sequence * array = (system_interfaces__msg__Display__Sequence *)allocator.allocate(sizeof(system_interfaces__msg__Display__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = system_interfaces__msg__Display__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
system_interfaces__msg__Display__Sequence__destroy(system_interfaces__msg__Display__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    system_interfaces__msg__Display__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
system_interfaces__msg__Display__Sequence__are_equal(const system_interfaces__msg__Display__Sequence * lhs, const system_interfaces__msg__Display__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!system_interfaces__msg__Display__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
system_interfaces__msg__Display__Sequence__copy(
  const system_interfaces__msg__Display__Sequence * input,
  system_interfaces__msg__Display__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(system_interfaces__msg__Display);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    system_interfaces__msg__Display * data =
      (system_interfaces__msg__Display *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!system_interfaces__msg__Display__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          system_interfaces__msg__Display__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!system_interfaces__msg__Display__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}

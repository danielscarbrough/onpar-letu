// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from system_interfaces:msg/Display.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "system_interfaces/msg/display.h"


#ifndef SYSTEM_INTERFACES__MSG__DETAIL__DISPLAY__STRUCT_H_
#define SYSTEM_INTERFACES__MSG__DETAIL__DISPLAY__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

// Constants defined in the message

/// Struct defined in msg/Display in the package system_interfaces.
typedef struct system_interfaces__msg__Display
{
  int64_t num_balls;
  int64_t num_putts;
} system_interfaces__msg__Display;

// Struct for a sequence of system_interfaces__msg__Display.
typedef struct system_interfaces__msg__Display__Sequence
{
  system_interfaces__msg__Display * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} system_interfaces__msg__Display__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // SYSTEM_INTERFACES__MSG__DETAIL__DISPLAY__STRUCT_H_

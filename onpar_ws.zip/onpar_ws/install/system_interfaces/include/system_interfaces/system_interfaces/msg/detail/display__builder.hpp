// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from system_interfaces:msg/Display.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "system_interfaces/msg/display.hpp"


#ifndef SYSTEM_INTERFACES__MSG__DETAIL__DISPLAY__BUILDER_HPP_
#define SYSTEM_INTERFACES__MSG__DETAIL__DISPLAY__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "system_interfaces/msg/detail/display__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace system_interfaces
{

namespace msg
{

namespace builder
{

class Init_Display_num_putts
{
public:
  explicit Init_Display_num_putts(::system_interfaces::msg::Display & msg)
  : msg_(msg)
  {}
  ::system_interfaces::msg::Display num_putts(::system_interfaces::msg::Display::_num_putts_type arg)
  {
    msg_.num_putts = std::move(arg);
    return std::move(msg_);
  }

private:
  ::system_interfaces::msg::Display msg_;
};

class Init_Display_num_balls
{
public:
  Init_Display_num_balls()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_Display_num_putts num_balls(::system_interfaces::msg::Display::_num_balls_type arg)
  {
    msg_.num_balls = std::move(arg);
    return Init_Display_num_putts(msg_);
  }

private:
  ::system_interfaces::msg::Display msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::system_interfaces::msg::Display>()
{
  return system_interfaces::msg::builder::Init_Display_num_balls();
}

}  // namespace system_interfaces

#endif  // SYSTEM_INTERFACES__MSG__DETAIL__DISPLAY__BUILDER_HPP_

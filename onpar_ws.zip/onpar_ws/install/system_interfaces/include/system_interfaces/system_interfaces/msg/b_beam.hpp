// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef SYSTEM_INTERFACES__MSG__B_BEAM_HPP_
#define SYSTEM_INTERFACES__MSG__B_BEAM_HPP_

#include "system_interfaces/msg/detail/b_beam__struct.hpp"
#include "system_interfaces/msg/detail/b_beam__builder.hpp"
#include "system_interfaces/msg/detail/b_beam__traits.hpp"
#include "system_interfaces/msg/detail/b_beam__type_support.hpp"

#endif  // SYSTEM_INTERFACES__MSG__B_BEAM_HPP_

// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from system_interfaces:msg/BBeam.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "system_interfaces/msg/b_beam.hpp"


#ifndef SYSTEM_INTERFACES__MSG__DETAIL__B_BEAM__TRAITS_HPP_
#define SYSTEM_INTERFACES__MSG__DETAIL__B_BEAM__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "system_interfaces/msg/detail/b_beam__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace system_interfaces
{

namespace msg
{

inline void to_flow_style_yaml(
  const BBeam & msg,
  std::ostream & out)
{
  out << "{";
  // member: good_putts
  {
    out << "good_putts: ";
    rosidl_generator_traits::value_to_yaml(msg.good_putts, out);
    out << ", ";
  }

  // member: short_putts
  {
    out << "short_putts: ";
    rosidl_generator_traits::value_to_yaml(msg.short_putts, out);
    out << ", ";
  }

  // member: long_putts
  {
    out << "long_putts: ";
    rosidl_generator_traits::value_to_yaml(msg.long_putts, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const BBeam & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: good_putts
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "good_putts: ";
    rosidl_generator_traits::value_to_yaml(msg.good_putts, out);
    out << "\n";
  }

  // member: short_putts
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "short_putts: ";
    rosidl_generator_traits::value_to_yaml(msg.short_putts, out);
    out << "\n";
  }

  // member: long_putts
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "long_putts: ";
    rosidl_generator_traits::value_to_yaml(msg.long_putts, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const BBeam & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace system_interfaces

namespace rosidl_generator_traits
{

[[deprecated("use system_interfaces::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const system_interfaces::msg::BBeam & msg,
  std::ostream & out, size_t indentation = 0)
{
  system_interfaces::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use system_interfaces::msg::to_yaml() instead")]]
inline std::string to_yaml(const system_interfaces::msg::BBeam & msg)
{
  return system_interfaces::msg::to_yaml(msg);
}

template<>
inline const char * data_type<system_interfaces::msg::BBeam>()
{
  return "system_interfaces::msg::BBeam";
}

template<>
inline const char * name<system_interfaces::msg::BBeam>()
{
  return "system_interfaces/msg/BBeam";
}

template<>
struct has_fixed_size<system_interfaces::msg::BBeam>
  : std::integral_constant<bool, true> {};

template<>
struct has_bounded_size<system_interfaces::msg::BBeam>
  : std::integral_constant<bool, true> {};

template<>
struct is_message<system_interfaces::msg::BBeam>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // SYSTEM_INTERFACES__MSG__DETAIL__B_BEAM__TRAITS_HPP_

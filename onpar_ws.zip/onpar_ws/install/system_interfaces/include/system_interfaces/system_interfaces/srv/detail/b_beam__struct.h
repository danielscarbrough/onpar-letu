// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from system_interfaces:srv/BBeam.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "system_interfaces/srv/b_beam.h"


#ifndef SYSTEM_INTERFACES__SRV__DETAIL__B_BEAM__STRUCT_H_
#define SYSTEM_INTERFACES__SRV__DETAIL__B_BEAM__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Struct defined in srv/BBeam in the package system_interfaces.
typedef struct system_interfaces__srv__BBeam_Request
{
  uint8_t structure_needs_at_least_one_member;
} system_interfaces__srv__BBeam_Request;

// Struct for a sequence of system_interfaces__srv__BBeam_Request.
typedef struct system_interfaces__srv__BBeam_Request__Sequence
{
  system_interfaces__srv__BBeam_Request * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} system_interfaces__srv__BBeam_Request__Sequence;

// Constants defined in the message

/// Struct defined in srv/BBeam in the package system_interfaces.
typedef struct system_interfaces__srv__BBeam_Response
{
  int64_t good_putts;
  int64_t short_putts;
  int64_t long_putts;
} system_interfaces__srv__BBeam_Response;

// Struct for a sequence of system_interfaces__srv__BBeam_Response.
typedef struct system_interfaces__srv__BBeam_Response__Sequence
{
  system_interfaces__srv__BBeam_Response * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} system_interfaces__srv__BBeam_Response__Sequence;

// Constants defined in the message

// Include directives for member types
// Member 'info'
#include "service_msgs/msg/detail/service_event_info__struct.h"

// constants for array fields with an upper bound
// request
enum
{
  system_interfaces__srv__BBeam_Event__request__MAX_SIZE = 1
};
// response
enum
{
  system_interfaces__srv__BBeam_Event__response__MAX_SIZE = 1
};

/// Struct defined in srv/BBeam in the package system_interfaces.
typedef struct system_interfaces__srv__BBeam_Event
{
  service_msgs__msg__ServiceEventInfo info;
  system_interfaces__srv__BBeam_Request__Sequence request;
  system_interfaces__srv__BBeam_Response__Sequence response;
} system_interfaces__srv__BBeam_Event;

// Struct for a sequence of system_interfaces__srv__BBeam_Event.
typedef struct system_interfaces__srv__BBeam_Event__Sequence
{
  system_interfaces__srv__BBeam_Event * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} system_interfaces__srv__BBeam_Event__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // SYSTEM_INTERFACES__SRV__DETAIL__B_BEAM__STRUCT_H_

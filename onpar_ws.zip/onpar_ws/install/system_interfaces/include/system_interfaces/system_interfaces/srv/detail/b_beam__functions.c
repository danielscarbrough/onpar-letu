// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from system_interfaces:srv/BBeam.idl
// generated code does not contain a copyright notice
#include "system_interfaces/srv/detail/b_beam__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"

bool
system_interfaces__srv__BBeam_Request__init(system_interfaces__srv__BBeam_Request * msg)
{
  if (!msg) {
    return false;
  }
  // structure_needs_at_least_one_member
  return true;
}

void
system_interfaces__srv__BBeam_Request__fini(system_interfaces__srv__BBeam_Request * msg)
{
  if (!msg) {
    return;
  }
  // structure_needs_at_least_one_member
}

bool
system_interfaces__srv__BBeam_Request__are_equal(const system_interfaces__srv__BBeam_Request * lhs, const system_interfaces__srv__BBeam_Request * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // structure_needs_at_least_one_member
  if (lhs->structure_needs_at_least_one_member != rhs->structure_needs_at_least_one_member) {
    return false;
  }
  return true;
}

bool
system_interfaces__srv__BBeam_Request__copy(
  const system_interfaces__srv__BBeam_Request * input,
  system_interfaces__srv__BBeam_Request * output)
{
  if (!input || !output) {
    return false;
  }
  // structure_needs_at_least_one_member
  output->structure_needs_at_least_one_member = input->structure_needs_at_least_one_member;
  return true;
}

system_interfaces__srv__BBeam_Request *
system_interfaces__srv__BBeam_Request__create(void)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  system_interfaces__srv__BBeam_Request * msg = (system_interfaces__srv__BBeam_Request *)allocator.allocate(sizeof(system_interfaces__srv__BBeam_Request), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(system_interfaces__srv__BBeam_Request));
  bool success = system_interfaces__srv__BBeam_Request__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
system_interfaces__srv__BBeam_Request__destroy(system_interfaces__srv__BBeam_Request * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    system_interfaces__srv__BBeam_Request__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
system_interfaces__srv__BBeam_Request__Sequence__init(system_interfaces__srv__BBeam_Request__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  system_interfaces__srv__BBeam_Request * data = NULL;

  if (size) {
    data = (system_interfaces__srv__BBeam_Request *)allocator.zero_allocate(size, sizeof(system_interfaces__srv__BBeam_Request), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = system_interfaces__srv__BBeam_Request__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        system_interfaces__srv__BBeam_Request__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
system_interfaces__srv__BBeam_Request__Sequence__fini(system_interfaces__srv__BBeam_Request__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      system_interfaces__srv__BBeam_Request__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

system_interfaces__srv__BBeam_Request__Sequence *
system_interfaces__srv__BBeam_Request__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  system_interfaces__srv__BBeam_Request__Sequence * array = (system_interfaces__srv__BBeam_Request__Sequence *)allocator.allocate(sizeof(system_interfaces__srv__BBeam_Request__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = system_interfaces__srv__BBeam_Request__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
system_interfaces__srv__BBeam_Request__Sequence__destroy(system_interfaces__srv__BBeam_Request__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    system_interfaces__srv__BBeam_Request__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
system_interfaces__srv__BBeam_Request__Sequence__are_equal(const system_interfaces__srv__BBeam_Request__Sequence * lhs, const system_interfaces__srv__BBeam_Request__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!system_interfaces__srv__BBeam_Request__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
system_interfaces__srv__BBeam_Request__Sequence__copy(
  const system_interfaces__srv__BBeam_Request__Sequence * input,
  system_interfaces__srv__BBeam_Request__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(system_interfaces__srv__BBeam_Request);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    system_interfaces__srv__BBeam_Request * data =
      (system_interfaces__srv__BBeam_Request *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!system_interfaces__srv__BBeam_Request__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          system_interfaces__srv__BBeam_Request__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!system_interfaces__srv__BBeam_Request__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}


bool
system_interfaces__srv__BBeam_Response__init(system_interfaces__srv__BBeam_Response * msg)
{
  if (!msg) {
    return false;
  }
  // good_putts
  // short_putts
  // long_putts
  return true;
}

void
system_interfaces__srv__BBeam_Response__fini(system_interfaces__srv__BBeam_Response * msg)
{
  if (!msg) {
    return;
  }
  // good_putts
  // short_putts
  // long_putts
}

bool
system_interfaces__srv__BBeam_Response__are_equal(const system_interfaces__srv__BBeam_Response * lhs, const system_interfaces__srv__BBeam_Response * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // good_putts
  if (lhs->good_putts != rhs->good_putts) {
    return false;
  }
  // short_putts
  if (lhs->short_putts != rhs->short_putts) {
    return false;
  }
  // long_putts
  if (lhs->long_putts != rhs->long_putts) {
    return false;
  }
  return true;
}

bool
system_interfaces__srv__BBeam_Response__copy(
  const system_interfaces__srv__BBeam_Response * input,
  system_interfaces__srv__BBeam_Response * output)
{
  if (!input || !output) {
    return false;
  }
  // good_putts
  output->good_putts = input->good_putts;
  // short_putts
  output->short_putts = input->short_putts;
  // long_putts
  output->long_putts = input->long_putts;
  return true;
}

system_interfaces__srv__BBeam_Response *
system_interfaces__srv__BBeam_Response__create(void)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  system_interfaces__srv__BBeam_Response * msg = (system_interfaces__srv__BBeam_Response *)allocator.allocate(sizeof(system_interfaces__srv__BBeam_Response), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(system_interfaces__srv__BBeam_Response));
  bool success = system_interfaces__srv__BBeam_Response__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
system_interfaces__srv__BBeam_Response__destroy(system_interfaces__srv__BBeam_Response * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    system_interfaces__srv__BBeam_Response__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
system_interfaces__srv__BBeam_Response__Sequence__init(system_interfaces__srv__BBeam_Response__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  system_interfaces__srv__BBeam_Response * data = NULL;

  if (size) {
    data = (system_interfaces__srv__BBeam_Response *)allocator.zero_allocate(size, sizeof(system_interfaces__srv__BBeam_Response), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = system_interfaces__srv__BBeam_Response__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        system_interfaces__srv__BBeam_Response__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
system_interfaces__srv__BBeam_Response__Sequence__fini(system_interfaces__srv__BBeam_Response__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      system_interfaces__srv__BBeam_Response__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

system_interfaces__srv__BBeam_Response__Sequence *
system_interfaces__srv__BBeam_Response__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  system_interfaces__srv__BBeam_Response__Sequence * array = (system_interfaces__srv__BBeam_Response__Sequence *)allocator.allocate(sizeof(system_interfaces__srv__BBeam_Response__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = system_interfaces__srv__BBeam_Response__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
system_interfaces__srv__BBeam_Response__Sequence__destroy(system_interfaces__srv__BBeam_Response__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    system_interfaces__srv__BBeam_Response__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
system_interfaces__srv__BBeam_Response__Sequence__are_equal(const system_interfaces__srv__BBeam_Response__Sequence * lhs, const system_interfaces__srv__BBeam_Response__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!system_interfaces__srv__BBeam_Response__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
system_interfaces__srv__BBeam_Response__Sequence__copy(
  const system_interfaces__srv__BBeam_Response__Sequence * input,
  system_interfaces__srv__BBeam_Response__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(system_interfaces__srv__BBeam_Response);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    system_interfaces__srv__BBeam_Response * data =
      (system_interfaces__srv__BBeam_Response *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!system_interfaces__srv__BBeam_Response__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          system_interfaces__srv__BBeam_Response__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!system_interfaces__srv__BBeam_Response__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}


// Include directives for member types
// Member `info`
#include "service_msgs/msg/detail/service_event_info__functions.h"
// Member `request`
// Member `response`
// already included above
// #include "system_interfaces/srv/detail/b_beam__functions.h"

bool
system_interfaces__srv__BBeam_Event__init(system_interfaces__srv__BBeam_Event * msg)
{
  if (!msg) {
    return false;
  }
  // info
  if (!service_msgs__msg__ServiceEventInfo__init(&msg->info)) {
    system_interfaces__srv__BBeam_Event__fini(msg);
    return false;
  }
  // request
  if (!system_interfaces__srv__BBeam_Request__Sequence__init(&msg->request, 0)) {
    system_interfaces__srv__BBeam_Event__fini(msg);
    return false;
  }
  // response
  if (!system_interfaces__srv__BBeam_Response__Sequence__init(&msg->response, 0)) {
    system_interfaces__srv__BBeam_Event__fini(msg);
    return false;
  }
  return true;
}

void
system_interfaces__srv__BBeam_Event__fini(system_interfaces__srv__BBeam_Event * msg)
{
  if (!msg) {
    return;
  }
  // info
  service_msgs__msg__ServiceEventInfo__fini(&msg->info);
  // request
  system_interfaces__srv__BBeam_Request__Sequence__fini(&msg->request);
  // response
  system_interfaces__srv__BBeam_Response__Sequence__fini(&msg->response);
}

bool
system_interfaces__srv__BBeam_Event__are_equal(const system_interfaces__srv__BBeam_Event * lhs, const system_interfaces__srv__BBeam_Event * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // info
  if (!service_msgs__msg__ServiceEventInfo__are_equal(
      &(lhs->info), &(rhs->info)))
  {
    return false;
  }
  // request
  if (!system_interfaces__srv__BBeam_Request__Sequence__are_equal(
      &(lhs->request), &(rhs->request)))
  {
    return false;
  }
  // response
  if (!system_interfaces__srv__BBeam_Response__Sequence__are_equal(
      &(lhs->response), &(rhs->response)))
  {
    return false;
  }
  return true;
}

bool
system_interfaces__srv__BBeam_Event__copy(
  const system_interfaces__srv__BBeam_Event * input,
  system_interfaces__srv__BBeam_Event * output)
{
  if (!input || !output) {
    return false;
  }
  // info
  if (!service_msgs__msg__ServiceEventInfo__copy(
      &(input->info), &(output->info)))
  {
    return false;
  }
  // request
  if (!system_interfaces__srv__BBeam_Request__Sequence__copy(
      &(input->request), &(output->request)))
  {
    return false;
  }
  // response
  if (!system_interfaces__srv__BBeam_Response__Sequence__copy(
      &(input->response), &(output->response)))
  {
    return false;
  }
  return true;
}

system_interfaces__srv__BBeam_Event *
system_interfaces__srv__BBeam_Event__create(void)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  system_interfaces__srv__BBeam_Event * msg = (system_interfaces__srv__BBeam_Event *)allocator.allocate(sizeof(system_interfaces__srv__BBeam_Event), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(system_interfaces__srv__BBeam_Event));
  bool success = system_interfaces__srv__BBeam_Event__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
system_interfaces__srv__BBeam_Event__destroy(system_interfaces__srv__BBeam_Event * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    system_interfaces__srv__BBeam_Event__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
system_interfaces__srv__BBeam_Event__Sequence__init(system_interfaces__srv__BBeam_Event__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  system_interfaces__srv__BBeam_Event * data = NULL;

  if (size) {
    data = (system_interfaces__srv__BBeam_Event *)allocator.zero_allocate(size, sizeof(system_interfaces__srv__BBeam_Event), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = system_interfaces__srv__BBeam_Event__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        system_interfaces__srv__BBeam_Event__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
system_interfaces__srv__BBeam_Event__Sequence__fini(system_interfaces__srv__BBeam_Event__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      system_interfaces__srv__BBeam_Event__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

system_interfaces__srv__BBeam_Event__Sequence *
system_interfaces__srv__BBeam_Event__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  system_interfaces__srv__BBeam_Event__Sequence * array = (system_interfaces__srv__BBeam_Event__Sequence *)allocator.allocate(sizeof(system_interfaces__srv__BBeam_Event__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = system_interfaces__srv__BBeam_Event__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
system_interfaces__srv__BBeam_Event__Sequence__destroy(system_interfaces__srv__BBeam_Event__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    system_interfaces__srv__BBeam_Event__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
system_interfaces__srv__BBeam_Event__Sequence__are_equal(const system_interfaces__srv__BBeam_Event__Sequence * lhs, const system_interfaces__srv__BBeam_Event__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!system_interfaces__srv__BBeam_Event__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
system_interfaces__srv__BBeam_Event__Sequence__copy(
  const system_interfaces__srv__BBeam_Event__Sequence * input,
  system_interfaces__srv__BBeam_Event__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(system_interfaces__srv__BBeam_Event);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    system_interfaces__srv__BBeam_Event * data =
      (system_interfaces__srv__BBeam_Event *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!system_interfaces__srv__BBeam_Event__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          system_interfaces__srv__BBeam_Event__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!system_interfaces__srv__BBeam_Event__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}

// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from system_interfaces:srv/MoveFlywheels.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "system_interfaces/srv/move_flywheels.hpp"


#ifndef SYSTEM_INTERFACES__SRV__DETAIL__MOVE_FLYWHEELS__BUILDER_HPP_
#define SYSTEM_INTERFACES__SRV__DETAIL__MOVE_FLYWHEELS__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "system_interfaces/srv/detail/move_flywheels__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace system_interfaces
{

namespace srv
{

namespace builder
{

class Init_MoveFlywheels_Request_direction
{
public:
  Init_MoveFlywheels_Request_direction()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::system_interfaces::srv::MoveFlywheels_Request direction(::system_interfaces::srv::MoveFlywheels_Request::_direction_type arg)
  {
    msg_.direction = std::move(arg);
    return std::move(msg_);
  }

private:
  ::system_interfaces::srv::MoveFlywheels_Request msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::system_interfaces::srv::MoveFlywheels_Request>()
{
  return system_interfaces::srv::builder::Init_MoveFlywheels_Request_direction();
}

}  // namespace system_interfaces


namespace system_interfaces
{

namespace srv
{

namespace builder
{

class Init_MoveFlywheels_Response_result
{
public:
  Init_MoveFlywheels_Response_result()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::system_interfaces::srv::MoveFlywheels_Response result(::system_interfaces::srv::MoveFlywheels_Response::_result_type arg)
  {
    msg_.result = std::move(arg);
    return std::move(msg_);
  }

private:
  ::system_interfaces::srv::MoveFlywheels_Response msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::system_interfaces::srv::MoveFlywheels_Response>()
{
  return system_interfaces::srv::builder::Init_MoveFlywheels_Response_result();
}

}  // namespace system_interfaces


namespace system_interfaces
{

namespace srv
{

namespace builder
{

class Init_MoveFlywheels_Event_response
{
public:
  explicit Init_MoveFlywheels_Event_response(::system_interfaces::srv::MoveFlywheels_Event & msg)
  : msg_(msg)
  {}
  ::system_interfaces::srv::MoveFlywheels_Event response(::system_interfaces::srv::MoveFlywheels_Event::_response_type arg)
  {
    msg_.response = std::move(arg);
    return std::move(msg_);
  }

private:
  ::system_interfaces::srv::MoveFlywheels_Event msg_;
};

class Init_MoveFlywheels_Event_request
{
public:
  explicit Init_MoveFlywheels_Event_request(::system_interfaces::srv::MoveFlywheels_Event & msg)
  : msg_(msg)
  {}
  Init_MoveFlywheels_Event_response request(::system_interfaces::srv::MoveFlywheels_Event::_request_type arg)
  {
    msg_.request = std::move(arg);
    return Init_MoveFlywheels_Event_response(msg_);
  }

private:
  ::system_interfaces::srv::MoveFlywheels_Event msg_;
};

class Init_MoveFlywheels_Event_info
{
public:
  Init_MoveFlywheels_Event_info()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_MoveFlywheels_Event_request info(::system_interfaces::srv::MoveFlywheels_Event::_info_type arg)
  {
    msg_.info = std::move(arg);
    return Init_MoveFlywheels_Event_request(msg_);
  }

private:
  ::system_interfaces::srv::MoveFlywheels_Event msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::system_interfaces::srv::MoveFlywheels_Event>()
{
  return system_interfaces::srv::builder::Init_MoveFlywheels_Event_info();
}

}  // namespace system_interfaces

#endif  // SYSTEM_INTERFACES__SRV__DETAIL__MOVE_FLYWHEELS__BUILDER_HPP_

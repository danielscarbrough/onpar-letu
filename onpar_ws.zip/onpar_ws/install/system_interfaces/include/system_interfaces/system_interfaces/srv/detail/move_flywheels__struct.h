// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from system_interfaces:srv/MoveFlywheels.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "system_interfaces/srv/move_flywheels.h"


#ifndef SYSTEM_INTERFACES__SRV__DETAIL__MOVE_FLYWHEELS__STRUCT_H_
#define SYSTEM_INTERFACES__SRV__DETAIL__MOVE_FLYWHEELS__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Struct defined in srv/MoveFlywheels in the package system_interfaces.
typedef struct system_interfaces__srv__MoveFlywheels_Request
{
  int64_t direction;
} system_interfaces__srv__MoveFlywheels_Request;

// Struct for a sequence of system_interfaces__srv__MoveFlywheels_Request.
typedef struct system_interfaces__srv__MoveFlywheels_Request__Sequence
{
  system_interfaces__srv__MoveFlywheels_Request * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} system_interfaces__srv__MoveFlywheels_Request__Sequence;

// Constants defined in the message

/// Struct defined in srv/MoveFlywheels in the package system_interfaces.
typedef struct system_interfaces__srv__MoveFlywheels_Response
{
  int64_t result;
} system_interfaces__srv__MoveFlywheels_Response;

// Struct for a sequence of system_interfaces__srv__MoveFlywheels_Response.
typedef struct system_interfaces__srv__MoveFlywheels_Response__Sequence
{
  system_interfaces__srv__MoveFlywheels_Response * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} system_interfaces__srv__MoveFlywheels_Response__Sequence;

// Constants defined in the message

// Include directives for member types
// Member 'info'
#include "service_msgs/msg/detail/service_event_info__struct.h"

// constants for array fields with an upper bound
// request
enum
{
  system_interfaces__srv__MoveFlywheels_Event__request__MAX_SIZE = 1
};
// response
enum
{
  system_interfaces__srv__MoveFlywheels_Event__response__MAX_SIZE = 1
};

/// Struct defined in srv/MoveFlywheels in the package system_interfaces.
typedef struct system_interfaces__srv__MoveFlywheels_Event
{
  service_msgs__msg__ServiceEventInfo info;
  system_interfaces__srv__MoveFlywheels_Request__Sequence request;
  system_interfaces__srv__MoveFlywheels_Response__Sequence response;
} system_interfaces__srv__MoveFlywheels_Event;

// Struct for a sequence of system_interfaces__srv__MoveFlywheels_Event.
typedef struct system_interfaces__srv__MoveFlywheels_Event__Sequence
{
  system_interfaces__srv__MoveFlywheels_Event * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} system_interfaces__srv__MoveFlywheels_Event__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // SYSTEM_INTERFACES__SRV__DETAIL__MOVE_FLYWHEELS__STRUCT_H_

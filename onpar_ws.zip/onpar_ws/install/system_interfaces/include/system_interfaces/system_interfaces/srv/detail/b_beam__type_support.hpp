// generated from rosidl_generator_cpp/resource/idl__type_support.hpp.em
// with input from system_interfaces:srv/BBeam.idl
// generated code does not contain a copyright notice

#ifndef SYSTEM_INTERFACES__SRV__DETAIL__B_BEAM__TYPE_SUPPORT_HPP_
#define SYSTEM_INTERFACES__SRV__DETAIL__B_BEAM__TYPE_SUPPORT_HPP_

#include "rosidl_typesupport_interface/macros.h"

#include "system_interfaces/msg/rosidl_generator_cpp__visibility_control.hpp"

#include "rosidl_typesupport_cpp/service_type_support.hpp"

#ifdef __cplusplus
extern "C"
{
#endif
// Forward declare the get type support functions for this type.
ROSIDL_GENERATOR_CPP_PUBLIC_system_interfaces
const rosidl_service_type_support_t *
  ROSIDL_TYPESUPPORT_INTERFACE__SERVICE_SYMBOL_NAME(
  rosidl_typesupport_cpp,
  system_interfaces,
  srv,
  BBeam
)();
#ifdef __cplusplus
}
#endif

#include "rosidl_typesupport_cpp/message_type_support.hpp"

#ifdef __cplusplus
extern "C"
{
#endif
// Forward declare the get type support functions for this type.
ROSIDL_GENERATOR_CPP_PUBLIC_system_interfaces
const rosidl_message_type_support_t *
  ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(
  rosidl_typesupport_cpp,
  system_interfaces,
  srv,
  BBeam_Request
)();
#ifdef __cplusplus
}
#endif

// already included above
// #include "rosidl_typesupport_cpp/message_type_support.hpp"

#ifdef __cplusplus
extern "C"
{
#endif
// Forward declare the get type support functions for this type.
ROSIDL_GENERATOR_CPP_PUBLIC_system_interfaces
const rosidl_message_type_support_t *
  ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(
  rosidl_typesupport_cpp,
  system_interfaces,
  srv,
  BBeam_Response
)();
#ifdef __cplusplus
}
#endif


#endif  // SYSTEM_INTERFACES__SRV__DETAIL__B_BEAM__TYPE_SUPPORT_HPP_

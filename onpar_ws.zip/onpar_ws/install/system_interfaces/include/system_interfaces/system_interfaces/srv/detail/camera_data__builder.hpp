// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from system_interfaces:srv/CameraData.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "system_interfaces/srv/camera_data.hpp"


#ifndef SYSTEM_INTERFACES__SRV__DETAIL__CAMERA_DATA__BUILDER_HPP_
#define SYSTEM_INTERFACES__SRV__DETAIL__CAMERA_DATA__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "system_interfaces/srv/detail/camera_data__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace system_interfaces
{

namespace srv
{


}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::system_interfaces::srv::CameraData_Request>()
{
  return ::system_interfaces::srv::CameraData_Request(rosidl_runtime_cpp::MessageInitialization::ZERO);
}

}  // namespace system_interfaces


namespace system_interfaces
{

namespace srv
{

namespace builder
{

class Init_CameraData_Response_ball_data
{
public:
  Init_CameraData_Response_ball_data()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::system_interfaces::srv::CameraData_Response ball_data(::system_interfaces::srv::CameraData_Response::_ball_data_type arg)
  {
    msg_.ball_data = std::move(arg);
    return std::move(msg_);
  }

private:
  ::system_interfaces::srv::CameraData_Response msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::system_interfaces::srv::CameraData_Response>()
{
  return system_interfaces::srv::builder::Init_CameraData_Response_ball_data();
}

}  // namespace system_interfaces


namespace system_interfaces
{

namespace srv
{

namespace builder
{

class Init_CameraData_Event_response
{
public:
  explicit Init_CameraData_Event_response(::system_interfaces::srv::CameraData_Event & msg)
  : msg_(msg)
  {}
  ::system_interfaces::srv::CameraData_Event response(::system_interfaces::srv::CameraData_Event::_response_type arg)
  {
    msg_.response = std::move(arg);
    return std::move(msg_);
  }

private:
  ::system_interfaces::srv::CameraData_Event msg_;
};

class Init_CameraData_Event_request
{
public:
  explicit Init_CameraData_Event_request(::system_interfaces::srv::CameraData_Event & msg)
  : msg_(msg)
  {}
  Init_CameraData_Event_response request(::system_interfaces::srv::CameraData_Event::_request_type arg)
  {
    msg_.request = std::move(arg);
    return Init_CameraData_Event_response(msg_);
  }

private:
  ::system_interfaces::srv::CameraData_Event msg_;
};

class Init_CameraData_Event_info
{
public:
  Init_CameraData_Event_info()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_CameraData_Event_request info(::system_interfaces::srv::CameraData_Event::_info_type arg)
  {
    msg_.info = std::move(arg);
    return Init_CameraData_Event_request(msg_);
  }

private:
  ::system_interfaces::srv::CameraData_Event msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::system_interfaces::srv::CameraData_Event>()
{
  return system_interfaces::srv::builder::Init_CameraData_Event_info();
}

}  // namespace system_interfaces

#endif  // SYSTEM_INTERFACES__SRV__DETAIL__CAMERA_DATA__BUILDER_HPP_

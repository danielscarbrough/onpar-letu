// generated from rosidl_generator_c/resource/idl.h.em
// with input from system_interfaces:srv/BBeam.idl
// generated code does not contain a copyright notice

#ifndef SYSTEM_INTERFACES__SRV__B_BEAM_H_
#define SYSTEM_INTERFACES__SRV__B_BEAM_H_

#include "system_interfaces/srv/detail/b_beam__struct.h"
#include "system_interfaces/srv/detail/b_beam__functions.h"
#include "system_interfaces/srv/detail/b_beam__type_support.h"

#endif  // SYSTEM_INTERFACES__SRV__B_BEAM_H_

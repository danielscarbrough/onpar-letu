// generated from rosidl_generator_c/resource/idl.h.em
// with input from system_interfaces:srv/MoveFlywheels.idl
// generated code does not contain a copyright notice

#ifndef SYSTEM_INTERFACES__SRV__MOVE_FLYWHEELS_H_
#define SYSTEM_INTERFACES__SRV__MOVE_FLYWHEELS_H_

#include "system_interfaces/srv/detail/move_flywheels__struct.h"
#include "system_interfaces/srv/detail/move_flywheels__functions.h"
#include "system_interfaces/srv/detail/move_flywheels__type_support.h"

#endif  // SYSTEM_INTERFACES__SRV__MOVE_FLYWHEELS_H_

// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from system_interfaces:srv/MoveDistance.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "system_interfaces/srv/move_distance.hpp"


#ifndef SYSTEM_INTERFACES__SRV__DETAIL__MOVE_DISTANCE__BUILDER_HPP_
#define SYSTEM_INTERFACES__SRV__DETAIL__MOVE_DISTANCE__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "system_interfaces/srv/detail/move_distance__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace system_interfaces
{

namespace srv
{

namespace builder
{

class Init_MoveDistance_Request_comeback
{
public:
  explicit Init_MoveDistance_Request_comeback(::system_interfaces::srv::MoveDistance_Request & msg)
  : msg_(msg)
  {}
  ::system_interfaces::srv::MoveDistance_Request comeback(::system_interfaces::srv::MoveDistance_Request::_comeback_type arg)
  {
    msg_.comeback = std::move(arg);
    return std::move(msg_);
  }

private:
  ::system_interfaces::srv::MoveDistance_Request msg_;
};

class Init_MoveDistance_Request_distance
{
public:
  Init_MoveDistance_Request_distance()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_MoveDistance_Request_comeback distance(::system_interfaces::srv::MoveDistance_Request::_distance_type arg)
  {
    msg_.distance = std::move(arg);
    return Init_MoveDistance_Request_comeback(msg_);
  }

private:
  ::system_interfaces::srv::MoveDistance_Request msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::system_interfaces::srv::MoveDistance_Request>()
{
  return system_interfaces::srv::builder::Init_MoveDistance_Request_distance();
}

}  // namespace system_interfaces


namespace system_interfaces
{

namespace srv
{

namespace builder
{

class Init_MoveDistance_Response_resulting_distance
{
public:
  Init_MoveDistance_Response_resulting_distance()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::system_interfaces::srv::MoveDistance_Response resulting_distance(::system_interfaces::srv::MoveDistance_Response::_resulting_distance_type arg)
  {
    msg_.resulting_distance = std::move(arg);
    return std::move(msg_);
  }

private:
  ::system_interfaces::srv::MoveDistance_Response msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::system_interfaces::srv::MoveDistance_Response>()
{
  return system_interfaces::srv::builder::Init_MoveDistance_Response_resulting_distance();
}

}  // namespace system_interfaces


namespace system_interfaces
{

namespace srv
{

namespace builder
{

class Init_MoveDistance_Event_response
{
public:
  explicit Init_MoveDistance_Event_response(::system_interfaces::srv::MoveDistance_Event & msg)
  : msg_(msg)
  {}
  ::system_interfaces::srv::MoveDistance_Event response(::system_interfaces::srv::MoveDistance_Event::_response_type arg)
  {
    msg_.response = std::move(arg);
    return std::move(msg_);
  }

private:
  ::system_interfaces::srv::MoveDistance_Event msg_;
};

class Init_MoveDistance_Event_request
{
public:
  explicit Init_MoveDistance_Event_request(::system_interfaces::srv::MoveDistance_Event & msg)
  : msg_(msg)
  {}
  Init_MoveDistance_Event_response request(::system_interfaces::srv::MoveDistance_Event::_request_type arg)
  {
    msg_.request = std::move(arg);
    return Init_MoveDistance_Event_response(msg_);
  }

private:
  ::system_interfaces::srv::MoveDistance_Event msg_;
};

class Init_MoveDistance_Event_info
{
public:
  Init_MoveDistance_Event_info()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_MoveDistance_Event_request info(::system_interfaces::srv::MoveDistance_Event::_info_type arg)
  {
    msg_.info = std::move(arg);
    return Init_MoveDistance_Event_request(msg_);
  }

private:
  ::system_interfaces::srv::MoveDistance_Event msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::system_interfaces::srv::MoveDistance_Event>()
{
  return system_interfaces::srv::builder::Init_MoveDistance_Event_info();
}

}  // namespace system_interfaces

#endif  // SYSTEM_INTERFACES__SRV__DETAIL__MOVE_DISTANCE__BUILDER_HPP_

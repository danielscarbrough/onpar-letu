from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():

	ld = LaunchDescription()
	bbeam_node = Node(
		package="bbeam_flywheel",
		executable="bbeam"
	)
	flywheel_node = Node(
		package="bbeam_flywheel",
		executable="flywheel"
	)

	motors_node = Node(
		package="display_motors",
		executable="motors"
	)
	display_node = Node(
		package="display_motors",
		executable="display"
	)

	
	ld.add_action(bbeam_node)
	ld.add_action(flywheel_node)
	ld.add_action(motors_node)
	ld.add_action(display_node)
	
	return ld
